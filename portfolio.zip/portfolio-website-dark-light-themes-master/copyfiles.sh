pwd
# cd /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes
cd  /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/
mkdir public
cp /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/index.html /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/public/
cp /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/manifest.json /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/public/
cp /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/serviceWorker.js /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/public/
cp /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/404.html /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/public/
cd  /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/public/
mkdir assets
cp -r /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/assets/* /Users/animeshrawat/Documents/Code/portfolio-website-dark-light-themes/public/assets
# cp ../index.html ../public/